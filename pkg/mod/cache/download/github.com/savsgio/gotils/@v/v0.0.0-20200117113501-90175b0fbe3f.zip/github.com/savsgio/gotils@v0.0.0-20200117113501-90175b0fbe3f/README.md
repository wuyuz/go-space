gotils
======

[![Build Status](https://travis-ci.org/savsgio/gotils.svg?branch=master)](https://travis-ci.org/savsgio/gotils)
[![Go Report Card](https://goreportcard.com/badge/github.com/savsgio/gotils)](https://goreportcard.com/report/github.com/savsgio/gotils)
[![GoDoc](https://godoc.org/github.com/savsgio/gotils?status.svg)](https://godoc.org/github.com/savsgio/gotils)

Golang utlities to make your life easier :wink:
