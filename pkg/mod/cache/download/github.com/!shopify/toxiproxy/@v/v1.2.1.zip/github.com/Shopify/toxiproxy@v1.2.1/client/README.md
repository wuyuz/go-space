# toxiproxy-go

This is the Go client library for the
[Toxiproxy](https://github.com/shopify/toxiproxy) API. Please read the [usage
section in the Toxiproxy README](https://github.com/shopify/toxiproxy#usage)
before attempting to use the client.

For Usage please [see the Godoc
documentation](http://godoc.org/github.com/Shopify/toxiproxy/client) for the
package.
