package cpu

type cpuTimes struct {
	User uint32
	Nice uint32
	Sys  uint32
	Intr uint32
	Idle uint32
}
